#!/bin/sh
cd D:/xammp/htdocs
php -f D:\xammp\htdocs\spalab\wp-content\plugins\designthemes-core-features/reservation/cron/send_agenda_cron.php